create procedure mygc(IN num varchar(20), OUT i int)
  BEGIN
    select money from blank where username=num into i;
    
    END;

