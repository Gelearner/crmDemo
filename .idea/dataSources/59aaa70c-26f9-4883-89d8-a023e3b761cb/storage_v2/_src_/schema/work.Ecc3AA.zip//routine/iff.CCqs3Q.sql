create procedure iff(IN num int, OUT str varchar(20))
  BEGIN
	if num=1 then 
	set str='星期一';
	elseif num=2 then
	set str='星期二';
	ELSEIF num=3 THEN
	SET str='星期三';
	ELSEIF num=4 THEN
	SET str='星期四';
	else 
	set str='输入有误';
	
	end if;
    END;

