create procedure whf(IN num int, OUT res int)
  BEGIN
	declare j int default 1;
	declare i int default 0;
	while j <=num do
	set i=i+j;
	SET j=j+1;
	end while;
	set res=i;
    END;

