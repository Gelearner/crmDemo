create procedure mygc2(INOUT a varchar(20))
  BEGIN
	select password from login where username = a into a;
    END;

